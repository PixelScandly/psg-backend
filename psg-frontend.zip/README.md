# PSG Ratio Frontend

This is a React + Tailwind CSS frontend app for fetching and displaying PSG ratios.

## Setup

1. Install dependencies:

```bash
npm install
```

2. Replace the API URL in `src/App.js` (the `fetch` URL) with your actual backend Render URL.

3. Run the app locally:

```bash
npm start
```

4. The app will open in your browser at [http://localhost:3000](http://localhost:3000).

## Build

To build for production:

```bash
npm run build
```

---

## Notes

- This project uses Tailwind CSS for styling.
- The backend API must be running and accessible from the frontend.